from lista import creareLista, tipar


def find_last_element(lista):
    if lista.prim is None:
        return None  # The list is empty
    return find_last_element_rec(lista.prim)

def find_last_element_rec(nod):
    if nod.urm is None:
        return nod.e
    return find_last_element_rec(nod.urm)


def delete_elements_between_positions(lista, start_pos, end_pos):
    lista.prim = delete_elements_between_positions_rec(lista.prim, 1, start_pos, end_pos)

def delete_elements_between_positions_rec(nod, current_pos, start_pos, end_pos):
    if nod is None:
        return None
    if start_pos < 0 or end_pos < 0:
        return None
    if start_pos <= current_pos <= end_pos:
        return delete_elements_between_positions_rec(nod.urm, current_pos + 1, start_pos, end_pos)
    else:
        nod.urm = delete_elements_between_positions_rec(nod.urm, current_pos + 1, start_pos, end_pos)
        return nod



my_list = creareLista()
print("Original list:")
tipar(my_list)


last = find_last_element(my_list)
print("Last element:", last)


n = 3
m = 5
delete_elements_between_positions(my_list, n, m)
print("Modified list after deleting elements from position {} to {}:".format(n, m))
tipar(my_list)